import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AirlineAdminComponent } from './airline-admin.component';

describe('AirlineAdminComponent', () => {
  let component: AirlineAdminComponent;
  let fixture: ComponentFixture<AirlineAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AirlineAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AirlineAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
