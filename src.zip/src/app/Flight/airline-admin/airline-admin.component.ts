import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'
import {airline} from 'src/app/models/airline-admin'

@Component({
  selector: 'app-airline-admin',
  templateUrl: './airline-admin.component.html',
  styleUrls: ['./airline-admin.component.css']
})
export class AirlineAdminComponent implements OnInit {
  data:any;
  constructor(private http: HttpClient,private auth:FlightService) { }
  airlineModal =new airline();
  ngOnInit(): void {
    
    this.auth.AirlineList()
    .subscribe(posts => {
      this.data = posts;
  });

}

onSubmit() {
  this.auth.AirlineAdd(this.airlineModal)
    .subscribe(res=> alert(res) ,
      err=>{alert("records create successfully"),
      this.ngOnInit();
    }
     
  );

}


airlineBlockedPopup(id:any){
  this.airlineModal.id=id;
    
}


AirlineBlocked(){
  this.auth.AirlineBlocked(this.airlineModal.id)
  .subscribe(res=> console.log(res) ,
    err=>{alert("Airline Blocked successfully"),
    this.ngOnInit();
  })
}

}
