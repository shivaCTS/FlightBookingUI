import { Component, OnInit } from '@angular/core';
import {coupon} from 'src/app/models/coupon-code'
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'
import {AuthService} from 'src/app/services/auth.service'

@Component({
  selector: 'app-coupon-code',
  templateUrl: './coupon-code.component.html',
  styleUrls: ['./coupon-code.component.css']
})
export class CouponCodeComponent implements OnInit {

  constructor(private http: HttpClient,private auth:FlightService,
    private login:AuthService,
    private route:ActivatedRoute, private routenevigate:Router) { }
    couponCode= new coupon();
    data:any
    couponcodeId:any
  ngOnInit(): void {
    this.auth.CouponCodeList()
    .subscribe(posts => {
      this.data = posts;
    })
  }
  deleteCouponCode(id:any){
this.couponcodeId=id;
  }
  onSubmit(){
    this.auth.CouponCodeAdd(this.couponCode)
    .subscribe(res=> console.log(res) ,
      err=>{alert("coupon saved successfully."),
      this.ngOnInit();
  }
      
  );
  }

  DeleteCouponCode(){
    this.auth.CouponCodeDelete(this.couponcodeId)
    .subscribe(res=> console.log(res) ,
      err=>{alert("coupon deleted successfully."),
      this.ngOnInit();
    }
      
  );
  }


}
