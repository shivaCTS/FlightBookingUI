import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'
import {flight} from 'src/app/models/Flight-admin'
import {Inventory} from 'src/app/models/inventory-admin'
import { post } from 'jquery';

@Component({
  selector: 'app-flight-admin',
  templateUrl: './flight-admin.component.html',
  styleUrls: ['./flight-admin.component.css']
})
export class FlightAdminComponent implements OnInit {
  data:any;
  ddlAirline:any
  constructor(private http: HttpClient,private auth:FlightService) { }
  flightModel =new flight();
inventoryModel=new Inventory();
  ngOnInit(): void {
    
    this.auth.FlightList()
    .subscribe(posts => {
      this.data = posts;
      console.log(this.data)
  });

  this.auth.AirlineDropDownList()
  .subscribe(posts => {
    this.ddlAirline = posts;
});

}

onSubmit(){
  this.auth.FlightAdd(this.flightModel)
    .subscribe(res=> console.log(res) ,
      err=>{alert("records create successfully"),
      this.ngOnInit();
    }   
  );
}
onInventorySubmit(){
  this.auth.ManageInventory(this.inventoryModel)
  .subscribe(res=> console.log(res) ,
    err=>{alert("records create successfully"),
    this.ngOnInit();
  }  
);
}
showPopData(id:any){

 // 
this.auth.DetailsInventory(id).subscribe(res=>res==null? this.reset(id)  : this.inventoryModel=res );

}

reset(id:any){
this.inventoryModel=new Inventory();
this.inventoryModel.flightNumber=id;
}
}

