import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'
import {tickethistory} from 'src/app/models/ticket-history'
import {AuthService} from 'src/app/services/auth.service'

@Component({
  selector: 'app-ticket-history',
  templateUrl: './ticket-history.component.html',
  styleUrls: ['./ticket-history.component.css']
})
export class TicketHistoryComponent implements OnInit {

  constructor(private http: HttpClient,private auth:FlightService,private login:AuthService) { }
  TicketData:any
  tickeId:any
search:any={
  "pnrNumber":0,
  "userId":this.login.GetUserID()
}
  ngOnInit(): void {
    this.auth.TicketList(this.search)
    .subscribe(posts => {
      this.TicketData = posts;
  });

  }

  CancelTicket(id:any){
   this.tickeId=id;
  }
  CancelTiketSubmit(){
    this.auth.CancelTicket(this.tickeId)
    .subscribe(res=> alert(res) ,
      err=>{alert("Ticket cancel successfully"),
      this.ngOnInit();
  })
  }

  PnrSeach(){
    this.auth.TicketList(this.search)
    .subscribe(posts => {
      this.TicketData = posts;
  });
  }

}
