import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'

@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.css']
})
export class UserSearchComponent implements OnInit {


  title = 'datatables';
  dtOptions: DataTables.Settings = {};
  data:any;
   search:any={
    "fromPlace": "",
    "toPlace": "",
    "startDate": "2022-06-23T06:15:33.518Z",
    "endDate": "2022-06-23T06:15:33.518Z",
    "oneWayTrip": true,
    "roundTrip": true
  }
  constructor(private http: HttpClient,private auth:FlightService) { }
   
  ngOnInit(): void {
    this.auth.SearchFlight(this.search)
    .subscribe(posts => {
      this.data = posts;
  });
    
  }

  SearchFlight(){
    this.auth.SearchFlight(this.search)
    .subscribe(posts => {
      this.data = posts;
  });
  }
}
