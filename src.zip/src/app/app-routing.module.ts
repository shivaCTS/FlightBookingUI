import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {RegisterComponent} from './register/register.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { WelcomeComponent } from './Flight/welcome/welcome.component'
import{AirlineAdminComponent} from './Flight/airline-admin/airline-admin.component'
import {FlightAdminComponent} from './Flight/flight-admin/flight-admin.component'
import { AuthGuard } from './auth.guard';
import {UserSearchComponent} from './Flight/user-search/user-search.component'
import {TicketHistoryComponent} from './Flight/ticket-history/ticket-history.component'
import {BookingTicketComponent} from 'src/app/booking-ticket/booking-ticket.component'
import {PnrStatusComponent} from 'src/app/pnr-status/pnr-status.component'
import {CouponCodeComponent} from 'src/app/Flight/coupon-code/coupon-code.component'
const routes: Routes = [

  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'',
    component:LoginComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'welcome',
   // redirectTo:"/flight/welcome",
    component:WelcomeComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'user-search',
   // redirectTo:"/flight/welcome",
    component:UserSearchComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'flight-admin',
   // redirectTo:"/flight/welcome",
    component:FlightAdminComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'airline-admin',
   // redirectTo:"/flight/welcome",
    component:AirlineAdminComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'ticket-history',
   // redirectTo:"/flight/welcome",
    component:TicketHistoryComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'user-search/booking-ticket/:id',
   // redirectTo:"/flight/welcome",
    component:BookingTicketComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'ticket-history/pnr-status/:id',
   // redirectTo:"/flight/welcome",
    component:PnrStatusComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'coupon-code',
   // redirectTo:"/flight/welcome",
    component:CouponCodeComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'**',
    component:PageNotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
