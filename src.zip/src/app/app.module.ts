import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http'

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component'
import { AuthService } from './services/auth.service';
import { WelcomeComponent } from './Flight/welcome/welcome.component'
import { AuthGuard } from './auth.guard';
import { TokenInterceptorService } from './services/token-interceptor.service';
import { UserSearchComponent } from './Flight/user-search/user-search.component';
import { TicketHistoryComponent } from './Flight/ticket-history/ticket-history.component'
import {DataTablesModule} from 'angular-datatables'
import {FlightService} from './services/flight.service';
import { AirlineAdminComponent } from 'src/app/Flight/airline-admin/airline-admin.component';
import { FlightAdminComponent } from 'src/app/Flight/flight-admin/flight-admin.component';
import { BookingTicketComponent } from './booking-ticket/booking-ticket.component';
import { PnrStatusComponent } from './pnr-status/pnr-status.component';
import { CouponCodeComponent } from 'src/app/Flight/coupon-code/coupon-code.component'


@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    LoginComponent,
    RegisterComponent,
    WelcomeComponent,
    UserSearchComponent,
    TicketHistoryComponent,
    AirlineAdminComponent,
    FlightAdminComponent,
    BookingTicketComponent,
    PnrStatusComponent,
    CouponCodeComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    DataTablesModule

  ],
  providers: [AuthService,FlightService, AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
