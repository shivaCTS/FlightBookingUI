import { Component, OnInit } from '@angular/core';
import {flightDetails,Passenger} from 'src/app/models/ticket-booking'
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'
import {AuthService} from 'src/app/services/auth.service'
import { noUndefined } from '@angular/compiler/src/util';


@Component({
  selector: 'app-booking-ticket',
  templateUrl: './booking-ticket.component.html',
  styleUrls: ['./booking-ticket.component.css']
})
export class BookingTicketComponent implements OnInit {
id:any

  constructor(private http: HttpClient,private auth:FlightService,
    private login:AuthService,
    private route:ActivatedRoute, private routenevigate:Router) { }
flight=new flightDetails();
passenger=new Passenger();
data:any
SelectedcouponCode?:string
  couponCode=[{
  "id":"",
  "code":"",
  "value":0
}]
couponVal:any
couponText:any
dataarray:any=[]
  ngOnInit(): void {
    this.id=this.route.snapshot.paramMap.get('id');
    this.dataarray.push(this.passenger);
    this.auth.DetailsInventory(this.id)
.subscribe(posts => {
  this.data = posts;
})

this.auth.CouponCodeList()
.subscribe(posts => {
  this.couponCode = posts;
})
  }

  onBookingSubmit(){
    this.flight.flightNumber=this.data.flightNumber;
    this.flight.totalPrice=this.flight.totalPrice * this.dataarray.length;
    this.flight.isMeals=true;
    this.flight.createdBy=this.login.GetUserID()?.toString();
    this.flight.Passenger=this.dataarray;
    if(this.couponVal!=undefined){
    this.flight.discount=this.couponVal
    this.flight.couponCode=this.couponText
    this.flight.finalPrice=this.flight.totalPrice- this.flight.discount
    }

    console.log(this.flight);

    
  }
  addPassenger(){
    this.passenger= new  Passenger();
    this.dataarray.push(this.passenger)
  }

  removeRow(index:any){
this.dataarray.splice(index);
  }
  

  CancelSubmit(e:any){
    $(e).hide();
    this.routenevigate.navigate(['/user-search'])
  }
  ddlchangeVal(e:any){
    let Val=this.couponCode.find(x=>x.id==e.target.value)
this.couponVal=Val?.value
   this.couponText=Val?.code
  }
  ddltripchangeVal(e:any){
    this.flight.totalPrice=e.target.value
  }
  BookTicketSubmit(){
    this.flight.totalPrice=this.flight.totalPrice- this.flight.discount
    
    this.auth.BookingTicket(this.flight)
    .subscribe(res=> console.log(res) ,
      err=>{alert("ticket booked successfully."),
      console.log(err)
  }
  );
  }
}
