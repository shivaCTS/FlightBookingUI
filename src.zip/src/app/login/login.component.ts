import { Component, OnInit,NgModule } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AuthService} from '../services/auth.service'
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor( private auth:AuthService,
    private route:Router
    ) { }

    
  btnLoginUser(user:any){
   
  this.auth.LoginUser(user)
  .subscribe(
    res=>{
     localStorage.setItem('token',res.token),
     localStorage.setItem('role',res.role),
     localStorage.setItem('userId',res.userId),
     localStorage.setItem('userName',res.userName),
 this.route.navigate(['/welcome'])
    },
    err=>console.log(err))
  }

  ngOnInit(): void {
  }

} 
