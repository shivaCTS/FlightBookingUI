export const BaseUrl = "http://localhost:5004/api/v1.0/";

export const BaseUrlLogin="http://localhost:53048/"
