  
export class flight {
    public flightNumber?: string
    
    public AirlineNunmber?: string
    public name?: string
}
