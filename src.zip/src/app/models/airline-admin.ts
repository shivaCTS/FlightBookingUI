
export class airline {
    public name: string="";
    public id: string="";
    public address: string="";
    public phone: string="";
    public logoUrl:string="NA"
}
