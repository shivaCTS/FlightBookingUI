
export class coupon {
    public code: string="";
    public value?: number
}