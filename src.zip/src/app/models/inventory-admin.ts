import { DecimalPipe } from "@angular/common"

export class Inventory {
    public id?: string
    public flightNumber?: string
    public fromPlace?: string
    public toPlace?: string
    public oneTripPrice: any
     public roundTripPrice:any
     public startDateTime: Date=new Date()
     public endDateTime:  Date=new Date()
     public scheduledDays?: string
     public instrumentUsed?: string
     public bussinessSeats?: number
     public nonBussinessSeats?: number
     public rowCounts?: number
     public meals?: string
     public createdBy?: string
  }