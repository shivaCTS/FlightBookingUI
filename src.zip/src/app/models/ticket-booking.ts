export class flightDetails {
 public pnrNumber?: number
    public flightNumber?: string
    public tripType:any
    public isMeals?: boolean
    public totalPrice?: any
    public createdBy?:string
    public discount:number=0
    public couponCode:string=""
    public finalPrice:any
    public Passenger?:[]
 }

 export class Passenger {
    public name?: string
       public gender?: string
       public age?: number
       public meals?: string
       public seatNo:string="NA"
       public createdBy?:string
    }