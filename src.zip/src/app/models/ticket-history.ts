 export class tickethistory {
 public pnrNumber?: number
    public flightNumber?: string
    public bockedSeats?: number
    public totalPrice?: any
 }