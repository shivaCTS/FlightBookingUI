import { Component, OnInit } from '@angular/core';
import {flightDetails,Passenger} from 'src/app/models/ticket-booking'
import { Router, ActivatedRoute } from '@angular/router';
import {HttpClient} from '@angular/common/http'
import {FlightService} from 'src/app/services/flight.service'
import {AuthService} from 'src/app/services/auth.service'
import html2canvas from 'html2canvas'   
import {jsPDF} from 'jspdf'
import { position } from 'html2canvas/dist/types/css/property-descriptors/position';

@Component({
  selector: 'app-pnr-status',
  templateUrl: './pnr-status.component.html',
  styleUrls: ['./pnr-status.component.css']
})
export class PnrStatusComponent implements OnInit {

  constructor(private http: HttpClient,private auth:FlightService,
    private login:AuthService,
    private route:ActivatedRoute, private routenevigate:Router) { }
id:any
data:any
  ngOnInit(): void {
    this.id=this.route.snapshot.paramMap.get('id');
    this.auth.PNRStatus(this.id)
    .subscribe(posts => {
      this.data = posts;
      console.log(this.data);
  });
  
  }
  generatePDF() {  
   const doc= new jsPDF();
   let data=document.getElementById("PdfContent");
   this.generate(data)
  }  

  generate(data:any){
    html2canvas(data).then(canvas=>{
      let imgwidth=290;
      let imgheight=(canvas.height*imgwidth/canvas.width);
      const contentDataURL=canvas.toDataURL('image/png')
      let pdf=new jsPDF('l','mm','a4');
      var positon=10
      pdf.addImage(contentDataURL,'PNG',0,positon,imgwidth,imgheight);
      pdf.save(this.id+".pdf");
    })
  }

  
}
