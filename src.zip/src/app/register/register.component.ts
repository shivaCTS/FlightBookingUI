import { Component, OnInit } from '@angular/core';
import {AuthService} from '../services/auth.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private http:AuthService,private route:Router) { }

  ngOnInit(): void {
  }
  btnRagisterUser(user:any){
    this.http.RegisterUser(user).subscribe(res=>alert(res.message) ,err=>alert("Records save successfully.") )
    //this.route.navigate(['/register']);
  }
}
