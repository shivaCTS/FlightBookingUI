import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Router, ActivatedRoute } from '@angular/router';
import {BaseUrl,BaseUrlLogin} from '../models/Constant'

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor( private http:HttpClient, private route:Router) { }

  LoginUser(LoginUser:any){
return this.http.post<any>(BaseUrlLogin+"login",LoginUser)
  }

 RegisterUser(user:any){
   return this.http.post<any>(BaseUrlLogin+"register",user)
      }


      loggedIn(){
        return !!localStorage.getItem('token')
      }
      getToken(){
        return localStorage.getItem('token')
      }
      logoutUser(){
        localStorage.removeItem('token');
        localStorage.removeItem('role'),
        localStorage.removeItem('userId');
        localStorage.removeItem('userName'),
        this.route.navigate(['/login'])
      }

      UserRoles(){
        return localStorage.getItem('role')
      }
      GetUserID(){
        return localStorage.getItem('userId')
      }
      GetUserName(){
        return localStorage.getItem('userName')
      }

}
