import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Router, ActivatedRoute } from '@angular/router';
import {Inventory} from 'src/app/models/inventory-admin'
import { flight } from '../models/Flight-admin';
import {BaseUrl} from '../models/Constant'

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private urlSearch = "http://localhost:5005/api/"
  constructor(private http: HttpClient, private route: Router) { }


  SearchFlight(search: any) {
    return this.http.post<any>(BaseUrl + "flight/searchFlight", search)
  }

  AirlineAdd(airline: any) {
    return this.http.post<any>(BaseUrl + "flight/airline/register", airline)
  }
  AirlineList() {
    return this.http.get<any>(this.urlSearch + "airline/list")
  }

  AirlineDropDownList() {
    return this.http.get<any>(this.urlSearch + "airline/ddlAirline")
  }

  AirlineBlocked(id: any) {
    return this.http.get<any>(this.urlSearch + "airline/BlockedAirline?id=" + id)
  }

  FlightList() {
    return this.http.get<any>(this.urlSearch + "flight/list")
  }
  FlightAdd(flight: any) {
    return this.http.post<any>(this.urlSearch + "flight/add", flight)
  }

  ManageInventory(inventory: any) {
    return this.http.post<any>(this.urlSearch + "inventory/add", inventory)
  }

  DetailsInventory(id: any) {
    return this.http.get<Inventory>(this.urlSearch + "inventory/details?id=" + id)
  }

  CancelTicket(id: any) {
    return this.http.get<any>(this.urlSearch + "Booking/CancelTicket?pnrNo=" + id)
  }

  TicketList(search:any) {
    return this.http.post<any>(this.urlSearch + "booking/TicketHistory",search)
  }
  BookingTicket(flight: any) {
    return this.http.post<any>(this.urlSearch + "booking/ticketBooking", flight)
  }
  PNRStatus(pnrNumber: any) {
    return this.http.get<any>(this.urlSearch + "booking/PNrDetails?pnrNo="+pnrNumber)
  }

  CouponCodeList() {
    return this.http.get<any>(this.urlSearch + "PromoCode/CouponCodeList")
  }
  CouponCodeAdd(data:any) {
    return this.http.post<any>(this.urlSearch + "PromoCode/CreateCouponCode",data)
  }
  CouponCodeDelete(id: any) {
    return this.http.get<any>(this.urlSearch + "PromoCode/DeleteCouponCode?id="+id)
  }

}
